package com.github.jfsql.demo;

public record Task(long id, String description, boolean completed) {

}
