package com.github.jfsql.parser.enums;

public enum JoinType {
    INNER_JOIN,
    LEFT_JOIN
}
