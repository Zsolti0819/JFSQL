package com.github.jfsql.parser.enums;

public enum OrderBy {
    ASC, DESC
}
