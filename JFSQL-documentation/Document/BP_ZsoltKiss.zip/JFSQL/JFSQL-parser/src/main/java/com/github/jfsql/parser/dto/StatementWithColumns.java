package com.github.jfsql.parser.dto;

import java.util.List;

public interface StatementWithColumns {

    List<String> getColumns();
}
