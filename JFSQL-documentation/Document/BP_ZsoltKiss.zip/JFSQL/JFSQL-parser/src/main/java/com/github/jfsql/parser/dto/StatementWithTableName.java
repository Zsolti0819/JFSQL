package com.github.jfsql.parser.dto;

public interface StatementWithTableName {

    String getTableName();
}
