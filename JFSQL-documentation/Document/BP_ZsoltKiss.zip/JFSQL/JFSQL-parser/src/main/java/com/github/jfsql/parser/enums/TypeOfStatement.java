package com.github.jfsql.parser.enums;

public enum TypeOfStatement {

    ALTER_TABLE,
    CREATE_TABLE,
    DELETE,
    DROP_TABLE,
    INSERT,
    SELECT,
    UPDATE
}
