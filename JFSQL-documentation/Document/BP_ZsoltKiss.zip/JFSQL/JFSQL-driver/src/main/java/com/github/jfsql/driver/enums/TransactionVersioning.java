package com.github.jfsql.driver.enums;

public enum TransactionVersioning {
    JGIT,
    DEFAULT
}
