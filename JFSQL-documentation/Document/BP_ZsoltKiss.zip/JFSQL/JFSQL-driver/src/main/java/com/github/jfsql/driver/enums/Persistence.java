package com.github.jfsql.driver.enums;

public enum Persistence {
    JSON,
    XML
}
